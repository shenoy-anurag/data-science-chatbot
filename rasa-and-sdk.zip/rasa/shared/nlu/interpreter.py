class NaturalLanguageInterpreter:
    """Remove once all old components are deleted."""

    pass


class RegexInterpreter:
    """Remove once all old components are deleted."""

    pass
